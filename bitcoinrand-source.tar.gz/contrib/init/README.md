Sample configuration files for:
```
SystemD: bitcoinrandd.service
Upstart: bitcoinrandd.conf
OpenRC:  bitcoinrandd.openrc
         bitcoinrandd.openrcconf
CentOS:  bitcoinrandd.init
macOS:    org.bitcoinrand.bitcoinrandd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
